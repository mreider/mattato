// Mattato TimeCockpit Bridge - Content Script
console.log('Mattato TimeCockpit Bridge loaded');

// Listen for messages from popup
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
    console.log('Received message:', request);
    
    if (request.action === 'test') {
        // Test basic functionality
        try {
            const currentDate = findCurrentWeekDate();
            sendResponse({
                success: true,
                message: currentDate ? `Found date: ${currentDate}` : 'Extension working, no date found'
            });
        } catch (error) {
            sendResponse({
                success: false,
                error: error.message
            });
        }
    }
    
    if (request.action === 'getPageInfo') {
        sendResponse({
            title: document.title,
            url: window.location.href,
            isTimeCockpit: window.location.href.includes('timecockpit.com')
        });
    }
    
    return true; // Keep message channel open for async response
});

// Function to find current week date from TimeCockpit page
function findCurrentWeekDate() {
    // Look for the date span with class tc-calendar-selected-day
    const dateSpan = document.querySelector('.tc-calendar-selected-day');
    if (dateSpan) {
        return dateSpan.textContent.trim();
    }
    
    // Fallback: look in the header
    const header = document.querySelector('.tc-calendar-selected-day-header');
    if (header) {
        // Extract date pattern from header text
        const datePattern = /([A-Z][a-z]+day,\s+[A-Z][a-z]+\s+\d{1,2},\s+\d{4})/;
        const match = header.textContent.match(datePattern);
        if (match) {
            return match[1];
        }
    }
    
    return null;
}

// Add visual indicator that extension is loaded
if (window.location.href.includes('timecockpit.com')) {
    const indicator = document.createElement('div');
    indicator.style.cssText = `
        position: fixed;
        top: 10px;
        right: 10px;
        background: #28a745;
        color: white;
        padding: 5px 10px;
        border-radius: 4px;
        font-size: 12px;
        z-index: 10000;
        font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    `;
    indicator.textContent = '🤖 Mattato Bridge Active';
    document.body.appendChild(indicator);
    
    // Remove indicator after 3 seconds
    setTimeout(() => {
        if (indicator.parentNode) {
            indicator.parentNode.removeChild(indicator);
        }
    }, 3000);
}
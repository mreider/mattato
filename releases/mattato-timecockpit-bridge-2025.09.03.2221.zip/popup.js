document.addEventListener('DOMContentLoaded', function() {
    const statusElement = document.getElementById('status');
    const testButton = document.getElementById('testButton');
    const infoButton = document.getElementById('infoButton');

    // Check if we're on TimeCockpit
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        const currentTab = tabs[0];
        if (currentTab.url && currentTab.url.includes('timecockpit.com')) {
            statusElement.textContent = 'Connected to TimeCockpit - Ready for integration';
            statusElement.className = 'status ready';
        } else {
            statusElement.textContent = 'Not on TimeCockpit page. Navigate to TimeCockpit first.';
            statusElement.className = 'status error';
        }
    });

    testButton.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: 'test'}, function(response) {
                if (response && response.success) {
                    statusElement.textContent = 'Test successful: ' + response.message;
                    statusElement.className = 'status ready';
                } else {
                    statusElement.textContent = 'Test failed: ' + (response ? response.error : 'No response');
                    statusElement.className = 'status error';
                }
            });
        });
    });

    infoButton.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            chrome.tabs.sendMessage(tabs[0].id, {action: 'getPageInfo'}, function(response) {
                if (response) {
                    statusElement.textContent = 'Page: ' + response.title + ' | URL: ' + response.url.substring(0, 50) + '...';
                    statusElement.className = 'status ready';
                }
            });
        });
    });
});